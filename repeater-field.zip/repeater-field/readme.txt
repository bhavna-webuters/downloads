=== Repeater Field ===
Tags: custom field, repeater field
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Just another plugin to add more fields.

== Description ==

Repeater Field can manage multiple fields including textbox, textarea, texteditor plus you can add more fields to wordpress posts and pages.

= Docs & Support =